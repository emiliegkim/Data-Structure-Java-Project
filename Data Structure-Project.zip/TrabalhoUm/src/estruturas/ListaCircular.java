package estruturas;

import java.util.Scanner;

public class ListaCircular {

	private Nodo inicio;

	public ListaCircular() {
		this.inicio = null;
	}

	public void insereValorListaCircular(int valor) {
		Nodo novo = new Nodo();
		novo.setValor(valor);
		// novo.setProx(this.inicio);// sempre que inserir no ultimo vagao, aponta para
		// o inicio -> faz ser circular
		if (this.inicio == null) {
			this.inicio = novo;
		} else {

			if (this.inicio.getProx() == null) {
				Nodo aux = this.inicio;
				while (aux.getProx() != null) {
					aux = aux.getProx();
				}
				aux.setProx(novo);

			}

			else {
				Nodo aux = this.inicio; // percorre a lista at� o null (�ltimo)
				while (aux.getProx() != this.inicio) {
					aux = aux.getProx();
				}
				aux.setProx(novo);
			}
		}
		novo.setProx(this.inicio);
	}

	public void imprimeValorListaCircular() {

		int cont = 0;

		// se a lista nao for vazia, imprimir o primeiro nodo do while
		if (this.inicio == null) {
			System.out.println("Lista vazia.");
		} else if (this.inicio.getProx() == null) {
			System.out.println(this.inicio);
			cont = 1;
		} else {
			Nodo aux = this.inicio;
			cont++;
			System.out.println("\n" + aux.getValor());
			aux = this.inicio.getProx();
			while (aux != this.inicio) {
				System.out.println("\n" + aux.getValor());
				aux = aux.getProx();
				cont++;
			}
		}
		System.out.println("\nO n�mero total de nodos na lista circular � :" + cont + "\n");

	}

	public void removeValorListaCircular() {

		if (this.inicio == null)
			System.out.println("Lista VAAAZIA!");
		else {
			if(this.inicio.getProx()==this.inicio) {
				this.inicio=null;
				System.out.println("probleminha");
			}
			else {
				Nodo aux=this.inicio;
				while(aux.getProx().getProx()!=this.inicio) {
					aux=aux.getProx();
				}
				aux.setProx(inicio);
			}
			
			/*
			Nodo aux = this.inicio;
			this.inicio = aux.getProx();
			aux = null;*/
		}
	}

	public void pesquisaValorListaCircular() {

		Nodo aux = this.inicio;
		int cont = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Pesquise um item: ");
		int pesq = sc.nextInt();

		while (aux != null && aux.getValor() != pesq) {

			aux = aux.getProx();
			cont++;
		}
		if (aux.getValor() == pesq) {
			System.out.println("Elemento " + pesq + " encontrado na posi��o: " + cont);
		} else {
			System.out.println("Item n�o encontrado.");
		}
		sc.close();

	}

	/*
	public void insereInicioListaCircular(int valor) {
		Nodo novo = new Nodo();
		novo.setValor(valor);
		novo.setProx(this.inicio);

		this.inicio = novo;
	}*/

	/*
	public void removeFinalListaCircular() {

		if (this.inicio == null)
			System.out.println("Lista VAAAZIA!");
		else {
			if (this.inicio.getProx() == null) {
				this.inicio = null;
			} else {
				Nodo aux = this.inicio;
				while (aux.getProx().getProx() != null)
					aux = aux.getProx();

				aux.setProx(null);
			}
		}
	}*/

}
