package estruturas;

import java.util.Scanner;

public class Pilha {

	private Nodo inicio;
	
	public Pilha() {
		this.inicio = null;
	}
	
	public void imprimeValorPilha() {
		Nodo aux = this.inicio;
		int cont = 0;

		while (aux != null) {
			
			System.out.println(aux.getValor());
			aux = aux.getProx();
			cont++;
		}
		System.out.println("\nO n�mero total de valores na pilha � :" + cont + "\n");
	}

	public void insereValorPilha(int valor) {

		Nodo novo = new Nodo();
		novo.setValor(valor);
		novo.setProx(null);

		this.inicio = novo;
	}

	public void removeInicioValorPilha() {
		if (this.inicio == null)
			System.out.println("Lista Vazia!");
		else {
			Nodo aux = this.inicio;
			this.inicio = aux.getProx();
			aux = null;
		}
	}
	
	public void pesquisaValorPilha() {
		  
		Nodo aux = this.inicio;
		int cont = 0;
		Scanner sc =new Scanner(System.in);
		System.out.println("Pesquise um item: ");
		int pesq= sc.nextInt();

		while(aux != null && aux.getValor()!= pesq) {

		aux = aux.getProx();
		cont++;
		}
		if(aux.getValor()== pesq) {
		System.out.println("Elemento "+pesq+" encontrado na posi��o: "+cont);
		}
		else {
		System.out.println("Item n�o encontrado.");
		}
		sc.close();
	  
	  }

}
