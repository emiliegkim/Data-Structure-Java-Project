package estruturas;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		
		Pilha pilha = new Pilha();
		Fila fila = new Fila();
		ListaCircular lc = new ListaCircular();

		int op = 0;
		
		while (op != 5){
		
		System.out.println("\n-----------------MENU-----------------\n");
		System.out.println("\nPOR FAVOR, ESCOLHA UMA OP��O: \n");
		System.out.println("1) Inserir valores na pilha, fila e lista circular;");
		System.out.println("2) Remover valores da pilha, fila e lista circular;");
		System.out.println("3) Imprimir valores da pilha, fila e lista circular;");
		System.out.println("4) Pesquisar valores na pilha, fila e lista circular;\n");
		System.out.println("5) Sair");
		
		Scanner sc=new Scanner(System.in);
		
		op=sc.nextInt();

		switch (op) {
		
		case 1:
			
			System.out.println("Informe um valor para a pilha: \n");
			int vp=sc.nextInt();
		
			System.out.println("Informe um valor para a fila: \n");
			int vf=sc.nextInt();
			
			System.out.println("Informe um valor para a lista circular: \n");
			int vlc=sc.nextInt();
			
			pilha.insereValorPilha(vp);
			fila.insereValorFila(vf);
			lc.insereValorListaCircular(vlc);
			
			System.out.println("\nValores inseridos com sucesso :) \n");
			
			break;
			
		case 2:
			
			pilha.removeInicioValorPilha();
			fila.removeValorFila();
			lc.removeValorListaCircular();

			break;
			
		case 3:
			
			pilha.imprimeValorPilha();
			fila.imprimeValorFila();
			lc.imprimeValorListaCircular();

			break;
			
		case 4:
			
			pilha.pesquisaValorPilha();
			fila.pesquisaValorFila();
			lc.pesquisaValorListaCircular();

			break;

		default:
			
			break;
			
		}

	}

}}
